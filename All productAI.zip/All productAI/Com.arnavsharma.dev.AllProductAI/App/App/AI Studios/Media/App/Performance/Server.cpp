#include <jni.h>
#include <string>
#include <thread>
#include <netinet/in.h>
#include <unistd.h>
#include <sstream>

#define BUFFER_SIZE 4096

std::string handle_request(const std::string& req) {
    if (req.find("GET /data") != std::string::npos) {
        // Return JSON
        return "HTTP/1.1 200 OK\r\n"
               "Content-Type: application/json\r\n"
               "Connection: close\r\n\r\n"
               "{ \"coder\": \"Arnav Sharma\", \"title\": \"The Real God of Coding 🚀\", \"age\": 8 }";
    } else {
        // Default HTML
        return "HTTP/1.1 200 OK\r\n"
               "Content-Type: text/html\r\n"
               "Connection: close\r\n\r\n"
               "<html><body><h1>🚀 Arnav's Android C++ Server</h1>"
               "<p>Fast, lightweight and awesome 👑🔥</p>"
               "<p>Try <a href='/data'>/data</a> for JSON</p></body></html>";
    }
}

void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE] = {0};
    read(client_socket, buffer, BUFFER_SIZE);
    std::string request(buffer);

    std::string response = handle_request(request);
    send(client_socket, response.c_str(), response.size(), 0);
    close(client_socket);
}

void start_server(int port) {
    int server_fd, client_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    bind(server_fd, (struct sockaddr*)&address, sizeof(address));
    listen(server_fd, 10);

    while (true) {
        client_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
        std::thread(handle_client, client_socket).detach();
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_arnav_arnavapp_MainActivity_startCppServer(JNIEnv* env, jobject, jint port) {
    std::thread server_thread(start_server, port);
    server_thread.detach();
}