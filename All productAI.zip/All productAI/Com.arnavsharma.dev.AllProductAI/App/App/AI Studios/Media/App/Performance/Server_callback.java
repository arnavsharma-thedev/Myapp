public class MainActivity extends AppCompatActivity {
    static {
        System.loadLibrary("arnav-lib");
    }

    public native void startCppServer(int port);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Start the C++ server
        startCppServer(8080);

        // Load WebView from the C++ server
        WebView webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("http://127.0.0.1:8080");
    }
}