This is, a non-copierightable product
All, Rights go to the Owner of this Reposetery
Thanks your, dear GitHub Team,
Thanks.
-Github
...